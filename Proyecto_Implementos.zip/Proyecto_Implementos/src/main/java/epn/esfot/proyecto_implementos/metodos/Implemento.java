package epn.esfot.proyecto_implementos.metodos;

public class Implemento {
    private int id, cantidad;
    private String nombre, categoria, deporte, codigo;

    public Implemento(int id, String codigo, String categoria, String nombre, String deporte, int cantidad) {
        this.id = id;
        this.cantidad = cantidad;
        this.nombre = nombre;
        this.categoria = categoria;
        this.deporte = deporte;
        this.codigo = codigo;
    }
    public Implemento(String codigo, String categoria, String nombre, String deporte, int cantidad) {
        this.cantidad = cantidad;
        this.nombre = nombre;
        this.categoria = categoria;
        this.deporte = deporte;
        this.codigo = codigo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
