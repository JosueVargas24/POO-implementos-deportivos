package epn.esfot.proyecto_implementos.metodos;

import java.util.Map;

public interface Crud {
    public Map<Integer, Implemento> listarTodo();
    public Implemento buscar(String codigo);
    public void agregar (Implemento implemento);
    public void eliminar (int id);
    public void editar (Implemento implemento);
    public Usuario obtenerUsuario (String usuario);
    public void agregarUsuario (Usuario usuario);
}
